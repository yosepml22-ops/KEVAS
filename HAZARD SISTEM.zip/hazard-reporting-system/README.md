# Hazard Reporting System
React + Vite + Firebase Authentication + Cloud Firestore + Vercel Functions.

## Fitur
- Login Firebase Email/Password.
- Dashboard statistik real-time dari Firestore.
- Buat laporan dengan judul, kategori, risiko, lokasi, dan deskripsi.
- Daftar laporan dengan pencarian, filter, detail, dan ekspor CSV.
- Admin mengubah status laporan.
- Admin membuat akun user melalui endpoint server Firebase Admin SDK.
- Custom claim admin diverifikasi di server; form tidak dapat memberikan role admin.
- UI hitam futuristik dengan aksen merah dan layout responsif.

## Jalankan di VS Code
1. Instal Node.js LTS dari https://nodejs.org/ dan VS Code.
2. Ekstrak ZIP lalu buka folder ini di VS Code.
3. Terminal > New Terminal:
   ```bash
   npm install
   ```
4. Buat project di https://console.firebase.google.com/ dan aktifkan Authentication > Sign-in method > Email/Password.
5. Buat Firestore Database.
6. Firebase Project settings > General > Your apps > Web app, salin konfigurasi.
7. Salin `.env.example` menjadi `.env.local`, lalu isi semua `VITE_FIREBASE_*`.
8. Firebase Console > Firestore > Rules, tempel `firestore.rules` lalu Publish.
9. Jalankan `npm run dev`, buka alamat localhost yang ditampilkan Vite.
10. Cek build dengan `npm run build`.

## Buat admin pertama
1. Firebase Console > Authentication > Add user, buat akun admin awal.
2. Buat service-account JSON dari Google Cloud IAM > Service Accounts. Simpan di luar folder project; jangan commit ke Git.
3. Atur variabel `GOOGLE_APPLICATION_CREDENTIALS` ke lokasi file itu:
   - Windows PowerShell: `$env:GOOGLE_APPLICATION_CREDENTIALS="C:\path\aman\service-account.json"`
   - macOS/Linux: `export GOOGLE_APPLICATION_CREDENTIALS="/path/aman/service-account.json"`
4. Jalankan `npm run set-admin -- admin@domain.com` dengan email akun tadi.
5. Logout lalu login kembali untuk memuat custom claim `admin: true`.

## Deploy ke Vercel
1. Push source ke repository GitHub; pastikan `.env.local` dan service account tidak ikut.
2. Import repository ke https://vercel.com/.
3. Tambahkan semua `VITE_FIREBASE_*` di Project Settings > Environment Variables.
4. Tambahkan `FIREBASE_SERVICE_ACCOUNT_JSON` sebagai variable server-side Vercel berisi JSON service account lengkap. Jangan beri prefix `VITE_`.
5. Deploy/redeploy, lalu tambahkan domain Vercel ke Firebase Authentication > Settings > Authorized domains bila belum ada.

## Catatan keamanan dan batasan
- Endpoint `/api/admin/users` hanya menerima POST, memverifikasi Firebase ID token dan custom claim admin, dan hanya membuat role `user`.
- Jangan pernah menetapkan custom claims dari browser. Role admin hanya melalui skrip tepercaya.
- Upload lampiran belum diimplementasikan; formulir laporan tidak menerima file pada versi ini.
- Uji Rules dengan akun user biasa dan admin sebelum pemakaian produksi. Untuk sistem keselamatan kerja sungguhan, tambah monitoring, backup, rate limiting, App Check, dan prosedur respons insiden.
